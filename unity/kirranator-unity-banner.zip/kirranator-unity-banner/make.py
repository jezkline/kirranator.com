"""kirranator Unity store promo banner — typed-text GIF, 1950x1300."""
import random, sys
from PIL import Image, ImageDraw, ImageFont

W, H = 1950, 1300
SS = 2  # supersample for clean edges
GREEN, WHITE = (0x84, 0xC5, 0x9D), (255, 255, 255)
FONT = sys.argv[1] if len(sys.argv) > 1 else "soopafresh.ttf"
OUT = sys.argv[2] if len(sys.argv) > 2 else "kirranator-unity-banner"

f1 = ImageFont.truetype(FONT, 330 * SS)
f2 = ImageFont.truetype(FONT, 118 * SS)
f3 = ImageFont.truetype(FONT, 104 * SS)

L1, L2 = "kirranator", "modular dev systems"
PRODUCTS = ["yapper", "decision-tree builder"]

def width(font, s):
    return font.getlength(s) if s else 0

# Left edge shared by all lines; block centered on the widest line.
w1 = width(f1, L1)
left = (W * SS - w1) / 2
# Vertical rhythm (baselines), block centered visually.
asc1 = -f1.getbbox("k", anchor="ls")[1]
pill_h = 172 * SS
gap12, gap23 = 175 * SS, 95 * SS
block_h = asc1 + gap12 + gap23 + pill_h
top = (H * SS - block_h) / 2
base1 = top + asc1
base2 = base1 + gap12
pill_top = base2 + gap23
pad_x = 44 * SS
asc3 = -f3.getbbox("x", anchor="ls")[1]
base3 = pill_top + pill_h / 2 + asc3 / 2 + 4 * SS


def render(n1, n2, t3, cur, cur_on):
    im = Image.new("RGB", (W * SS, H * SS), GREEN)
    d = ImageDraw.Draw(im)
    s1, s2 = L1[:n1], L2[:n2]
    d.text((left, base1), s1, font=f1, fill=WHITE, anchor="ls")
    d.text((left, base2), s2, font=f2, fill=WHITE, anchor="ls")
    if t3 is not None:
        pw = width(f3, t3) + 2 * pad_x + (26 * SS if cur == 3 else 0)
        d.rounded_rectangle((left, pill_top, left + pw, pill_top + pill_h),
                            radius=pill_h / 2, fill=WHITE)
        d.text((left + pad_x, base3), t3, font=f3, fill=GREEN, anchor="ls")
    if cur_on:
        if cur == 1:
            x, b, h, w, c = left + width(f1, s1) + 18 * SS, base1, asc1 * 0.98, 30 * SS, WHITE
        elif cur == 2:
            x, b, h, w, c = left + width(f2, s2) + 12 * SS, base2, 98 * SS, 13 * SS, WHITE
        else:
            x, b, h, w, c = left + pad_x + width(f3, t3) + 10 * SS, base3, 88 * SS, 12 * SS, GREEN
        d.rectangle((x, b - h, x + w, b + 6 * SS), fill=c)
    return im.resize((W, H), Image.LANCZOS)


rng = random.Random(7)
tl = []  # (state, ms)

def hold(state, ms, blink=True):
    n1, n2, t3, cur = state
    t = 0
    on = True
    while t < ms:
        step = min(500, ms - t)
        tl.append(((n1, n2, t3, cur, on if blink else True), step))
        t += step
        on = not on

def jit(ms):
    return int(ms * rng.uniform(0.7, 1.35))

# 1. blinking cursor on empty canvas
hold((0, 0, None, 1), 1000)
# 2. type wordmark
for i in range(1, len(L1) + 1):
    tl.append(((i, 0, None, 1, True), jit(95)))
hold((len(L1), 0, None, 1), 500)
# 3. type tagline
for i in range(1, len(L2) + 1):
    tl.append(((len(L1), i, None, 2, True), jit(55)))
hold((len(L1), len(L2), None, 2), 700)
# 4. products: type, hold, backspace
for pi, p in enumerate(PRODUCTS):
    tl.append(((len(L1), len(L2), "", 3, True), 120))
    for i in range(1, len(p) + 1):
        tl.append(((len(L1), len(L2), p[:i], 3, True), jit(70)))
    hold((len(L1), len(L2), p, 3), 2000)
    if pi < len(PRODUCTS) - 1:
        for i in range(len(p) - 1, -1, -1):
            tl.append(((len(L1), len(L2), p[:i], 3, True), 35))
# 5. erase everything fast, then loop
p = PRODUCTS[-1]
for i in range(len(p) - 1, -1, -1):
    tl.append(((len(L1), len(L2), p[:i], 3, True), 18))
for i in range(len(L2) - 1, -1, -1):
    tl.append(((len(L1), i, None, 2, True), 18))
for i in range(len(L1) - 1, -1, -1):
    tl.append(((i, 0, None, 1, True), 30))

# merge consecutive identical states; GIF delays are 10ms units
merged = []
for st, ms in tl:
    if merged and merged[-1][0] == st:
        merged[-1][1] += ms
    else:
        merged.append([st, ms])

cache = {}
frames, durs = [], []
for st, ms in merged:
    if st not in cache:
        cache[st] = render(*st)
    frames.append(cache[st])
    durs.append(max(20, round(ms / 10) * 10))

# fixed palette from a full frame so colors never shift between frames
ref = render(len(L1), len(L2), "decision-tree builder", 3, True)
pal = ref.quantize(colors=32, method=Image.MEDIANCUT)
q = [fr.quantize(palette=pal, dither=Image.Dither.NONE) for fr in frames]
q[0].save(f"{OUT}.gif", save_all=True, append_images=q[1:], duration=durs,
          loop=0, optimize=False, disposal=1)

# static fallbacks
render(len(L1), len(L2), "yapper", 3, False).save(f"{OUT}-static-yapper.png")
render(len(L1), len(L2), "decision-tree builder", 3, False).save(f"{OUT}-static-decision-tree.png")

# frame list for an mp4 via ffmpeg concat
with open("frames.txt", "w") as fh:
    for i, (fr, ms) in enumerate(zip(frames, durs)):
        path = f"fr/{i:04d}.png"
        fr.save(path)
        fh.write(f"file '{path}'\nduration {ms/1000:.3f}\n")
    fh.write(f"file 'fr/{len(frames)-1:04d}.png'\n")
print(len(frames), "frames,", sum(durs) / 1000, "s")
